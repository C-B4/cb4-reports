from setuptools import setup

setup(name='result_fetcher',
      version='0.1',
      description='Result fetcher from CB4',
      author='CB4',
      packages=['result_fetcher'],
      zip_safe=False)